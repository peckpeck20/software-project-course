export const MEDIA_WEB_SERVER_URL =
      "http://myy.haaga-helia.fi/~valju/people_images/";

export const DYNAMIC_WEB_SERVICE_API_SERVER_URL =
      "http://proto372.haaga-helia.fi/44444";

/* Not in use yet
export const STATIC_WEB_SERVER_URL ="http://myy.haaga-helia.fi/~valju/people_site/";
*/
